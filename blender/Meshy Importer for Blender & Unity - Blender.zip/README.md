# Meshy Importer for Blender & Unity

**Version 1.1.0 — created and maintained by FISHHWB**

Import real Meshy `.meshy` model payloads directly into Blender. The decoder runs locally and passes the reconstructed GLB to Blender's native glTF importer.

## Compatibility

- **Blender 3.6 LTS–4.1:** supported through the legacy Add-on workflow.
- **Blender 4.2+:** supported through the Extensions / Install from Disk workflow.
- **Blender 5.x:** supported through the Extensions workflow.

Blender 4.2 introduced the Extensions system while continuing to support legacy add-ons.

## Install

### Blender 4.2+
1. Open **Edit > Preferences > Extensions**.
2. Choose **Install from Disk**.
3. Select this ZIP.
4. Enable **Meshy Importer for Blender & Unity**.

### Blender 3.6–4.1
1. Open **Edit > Preferences > Add-ons**.
2. Choose **Install...**.
3. Select this ZIP.
4. Enable **Meshy Importer for Blender & Unity**.

## Import

Use **File > Import > Meshy Model (.meshy)**.

The add-on reconstructs the GLB in temporary storage and immediately passes it to Blender's native glTF importer; the temporary GLB is removed after import.

## How to get a `.meshy` file

1. Open your Meshy model in Chrome.
2. Press **F12** or **Ctrl+Shift+I**.
3. Open **Network** and reload the model.
4. Search/filter for **`model`**.
5. Find the actual model payload request.
6. Save its response/body and verify it starts with **`MESHY.AI`**.

Do **not** rename a GLB, FBX, OBJ, HTML page, or JSON response to `.meshy`. The web request name can change when Meshy updates its site.

## Support

Patreon: https://www.patreon.com/cw/DedZed

GitHub: https://github.com/dedzedofficial/Meshy-Importer-for-Blender-Unity

Discord: https://discord.gg/vCcsnX4HQP
